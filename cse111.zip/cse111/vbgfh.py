# Create a dictionary of atomic masses
atomic_masses = {
    'H': 1.00794,
    'He': 4.002602,
    # Add more elements here
}

# Define the make_periodic_table function
def make_periodic_table():
    # Create an empty compound list
    periodic_table = []
    # Add sublists for each element
    periodic_table.append(['H', 'Hydrogen', 1])
    periodic_table.append(['He', 'Helium', 2])
    # Add more elements here
    # Return the compound list
    return periodic_table

# Define the get_mass function
def get_mass(formula):
    # Import the re module
    import re
    # Initialize the mass to zero
    mass = 0
    # Use re.findall to extract the element symbols and quantities
    parts = re.findall('[A-Z][a-z]?|[0-9]+', formula)
    # Loop through the parts
    for index in range(len(parts)):
        # If the part is numeric, skip it
        if parts[index].isnumeric():
            continue
        # Get the element symbol
        symbol = parts[index]
        # Get the quantity, or assume 1 if not specified
        quantity = int(parts[index + 1]) if len(parts) > index + 1 and parts[index + 1].isnumeric() else 1
        # Get the atomic mass from the dictionary
        mass += atomic_masses[symbol] * quantity
    # Return the mass
    return mass

# Define the main function
def main():
    # Call the make_periodic_table function and store the result
    periodic_table = make_periodic_table()
    # Print a welcome message
    print('Welcome to the molar mass calculator!')
    # Use a loop to repeat the calculation
    while True:
        # Prompt the user to enter a chemical formula
        formula = input('Enter a chemical formula (or Q to quit): ')
        # If the formula is blank or Q, break the loop
        if formula == '' or formula == 'Q':
            break
        # Try to calculate and print the molar mass
        try:
            mass = get_mass(formula)
            print(f'The molar mass of {formula} is {mass:.3f} g/mol')
        # Handle any exceptions
        except KeyError:
            print('Invalid element symbol')
        except ValueError:
            print('Invalid quantity')
        except Exception as e:
            print('An error occurred:', e)
    # Print a goodbye message
    print('Thank you for using the molar mass calculator!')

# Call the main function
if __name__ == '__main__':
    main()

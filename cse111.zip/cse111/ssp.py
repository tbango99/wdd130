import csv
product=['price']
# define the function to read a CSV file and return a list of dictionaries
def read_dictionary(filename):
    # create an empty list to store the data
    data = []
    # open the CSV file in read mode
    with open(filename, 'rt') as file:
        # create a csv.DictReader object, passing the file object and the field names
        reader = csv.DictReader(file, fieldnames=['name', 'price', 'quantity'])
        # loop through the rows of the CSV file
        for row in reader:
            # append each row as a dictionary to the data list
            data.append(row)
    # return the data list
    return data

# define the main function
def main():
    # read the products.csv file and store the data in a variable
    products = read_dictionary('products.csv')
    # read the request.csv file and store the data in a variable
    request = read_dictionary('request.csv')
    # create an empty list to store the items ordered by the customer
    order = []
    # create a variable to store the total cost of the order
    total = 0
    # loop through the request list
    for item in request:
        # loop through the products list
        for product in products:
            # check if the name of the item matches the name of the product
            if item['name'] == product['name']:
                # calculate the cost of the item by multiplying the price and the quantity
                cost = (product['price']) * int(item['quantity'])
                # add the cost to the total
                total += cost
                # create a dictionary with the name, quantity, and cost of the item
                order_item = {'name': item['name'], 'quantity': item['quantity'], 'cost': cost}
                # append the order item to the order list
                order.append(order_item)
                # break the inner loop
                break
    # print the receipt to the terminal window
    print('Receipt for your grocery order:')
    print('-' * 30)
    # loop through the order list
    for order_item in order:
        # print the name, quantity, and cost of each item, formatted to two decimal places
        print(f"{order_item['name']}: {order_item['quantity']} x ${order_item['cost']:.2f}")
    print('-' * 30)
    # print the total cost of the order, formatted to two decimal places
    print(f"Total: ${total:.2f}")
    print('-' * 30)
    print('Thank you for shopping with us!')

# call the main function
#if __name__ == "__main__":
         # main()


import math

def calculate_rectangle_area(length, width):
    return length * width

def calculate_rectangle_diagonal(length, width):
    return math.sqrt(length**2 + width**2)

length = float(input("Enter the length of the rectangle: "))
width = float(input("Enter the width of the rectangle: "))

area = calculate_rectangle_area(length, width)
diagonal = calculate_rectangle_diagonal(length, width)

print(f"The area of the rectangle is {area} square units.")
print(f"The length of the diagonal of the rectangle is {diagonal} units.")
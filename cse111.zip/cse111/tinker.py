 #Import tkinter module
import tkinter as tk

# Create a root window
root = tk.Tk()

# Create a frame to hold the widgets
frame = tk.Frame(root)

# Create a label to display some text
label = tk.Label(frame, text="Hello, this is a simple GUI program")

# Create a text field to enter some input
entry = tk.Entry(frame)

# Create a button to perform some action
button = tk.Button(frame, text="Click me", command=lambda: print(entry.get()))

# Pack the widgets into the frame
label.pack()
entry.pack()
button.pack()

# Pack the frame into the root window
frame.pack()

# Start the main loop
root.mainloop()
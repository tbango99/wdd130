# always remember that should import function for programms that request and below that import function days, year, and time.
from datetime import datetime
#datetime.now(tz=None)
#datetime.weekday()
current_date_and_time = datetime.now()
day_of_the_week = current_date_and_time.weekday()
subtotal = float(input('Please enter the subtotal: '))
if(subtotal>= 50 and (day_of_the_week == 5 or day_of_the_week == 6)):
   discount =subtotal *0.1
   subtotal-=discount
   print(f'Discount amount : {discount:.2f}')
else:
  discount = 0.0
  print('No discount is applied')
sale_tax = subtotal *0.06
total_amount_due = subtotal + sale_tax

print(f'sales tax amount: {sale_tax: .2f}')
print(f'Total: {total_amount_due: .2f}')
print(f'Date and Time\n {day_of_the_week}') 
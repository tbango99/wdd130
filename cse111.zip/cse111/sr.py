PERIODIC_TABLE = {
    'H': 1.007,
    'He': 4.002,
    # Add the rest of the elements
}

def main():
    # This is the main function
    formula = input("Enter a chemical formula: ")
    molar_mass = compute_molar_mass(formula)
    print(f"The molar mass of {formula} is {molar_mass}")

def make_periodic_table():
    # This function will create and return the periodic table
    return PERIODIC_TABLE

def compute_molar_mass(formula):
    # This function will compute the molar mass of the given formula
    periodic_table = make_periodic_table()
    molar_mass = 0
    # Compute the molar mass using the formula and the periodic table
    return molar_mass

# Call the main function
if __name__ == "__main__":
    main()

color=('Brown')
favorite=('Your favorite color is\n')
print(favorite + color)


from collections import Counter
import re

def count_words(file_path):
    with open(file_path, 'r') as file:
        text = file.read().lower()
        words = re.findall(r'\b\w+\b', text)
        word_counts = Counter(words)
        
    return word_counts

# Test the function with a file path
word_counts = count_words('your_file.txt')

# Print the word counts
for word, count in word_counts.items():
    print(f"'{word}': {count}")
from pytest import approx
import pytest 

test_water_column_height =()

test_pressure_loss_from_fittings =()

test_reynolds_number = ()

test_pressure_loss_from_pipe_reduction =()

test_pressure_gain_from_water_height =()

test_pressure_loss_from_pipe =()

# Call the main function that is part of pytest so that the
# computer will execute the test functions in this file.
pytest.main(["-v", "--tb=line", "-rN", __file__])

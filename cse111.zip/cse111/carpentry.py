length = float(input("Enter the length in inches: "))
width = float(input("Enter the width in inches: "))
thickness = float(input("Enter the thickness in inches: "))


def calculate_board_feet(length, width, thickness):
    """Calculate the board feet of a piece of lumber."""
    volume = length * width * thickness
    board_feet = volume / 144
    return board_feet

def calculate_rafter_length(run, pitch):
    """Calculate the length of a rafter given the run and pitch."""
    rise = run * pitch
    length = (run ** 2 + rise ** 2) ** 0.5
    return length

def calculate_stair_rise(run, total_rise):
    """Calculate the rise of each stair given the run and total rise."""
    num_steps = total_rise / run
    rise = total_rise / num_steps
    return rise

def calculate_stair_run(rise, total_run):
    """Calculate the run of each stair given the rise and total run."""
    num_steps = total_run / rise
    run = total_run / num_steps
    return run
#board_feet = calculate_board_feet(length, width, thickness)

print(f"The board feet of a  piece of lumber is {calculate_board_feet:.2f}.")

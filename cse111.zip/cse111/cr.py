symbol_quantity_list = [["H", 2], ["O", 1]]
periodic_table_dict = {"H": [1, 1.00794], "O": [8, 15.9994]}
print(compute_molar_mass(symbol_quantity_list, periodic_table_dict))
def make_periodic_table():
    periodic_table_list = {
        # [symbol, name, atomic_mass]
        ["Ac", "Actinium", 227],
        ["Ag", "Silver", 107.8682],
        ["Al", "Aluminum", 26.9815386],
          
    }
    return periodic_table

def main():
    periodic_table = make_periodic_table()
    print(periodic_table)


if __name__ == "__main__":
    main()
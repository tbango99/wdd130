import csv

# Define the read_dictionary function
def read_dictionary(filename, key_column_index):

    # Create an empty dictionary
    dictionary = {}

    # Open the file for reading
    with open(filename, "r") as file:
        # Create a csv reader object
        reader = csv.reader(file)

        # Skip the first line (header)
        next(reader)

        # Loop through each row in the file
        for row in reader:
            # Get the key from the specified column
            key = row[key_column_index]

            # Add the row as a value to the dictionary with the key
            dictionary[key] = row

    # Return the dictionary
    return dictionary

# Define the main function
def main():
    # Call the read_dictionary function and store the compound dictionary in a variable named products_dict
    products_dict = read_dictionary("products.csv", 0)

    # Print the products_dict
    print(products_dict)

    # Open the request.csv file for reading
    with open("request.csv", "r") as file:
        # Create a csv reader object
        reader = csv.reader(file)

        # Skip the first line (header)
        next(reader)

        # Loop through each row in the file
        for row in reader:
            # Get the product number and quantity from the row
            product_number = row[0]
            quantity = int(row[1])

            # Use the product number to find the corresponding item in the products_dict
            item = products_dict[product_number]

            # Get the product name and price from the item
            product_name = item[1]
            price = float(item[2])

            # Print the product name, requested quantity, and product price
            print(product_name, quantity, price)

# Call the main function
main()
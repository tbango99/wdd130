import  random
from tkinter import WORD

def main():
    get_determiner
    get_noun
    get_verb 
      
    pass
def get_determiner(quantity):
    if quantity == 1:
        words = ["a", "one", "the"]
    else:
        words = ["some", "many", "the"]
        word = random.choice(words)
        
        return word
def get_noun(quantity):
    if quantity :
        nouns = ["bird", "boy", "car", "cat","child", "dog", "girl", "man", "rabbit", "woman"]
    else:
        nouns = ["birds","boys", "cars","cats", "children", "dogs", "girls", "men", "rabbits","women"]
        nouns = random.choice()
        return  nouns
def get_verb(quantity, tense):
    if tense :
         ["drank", "ate", "grew", "laughed", "thought", "ran", "slept", "talked", "walked", "wrote"]
                 
    if tense and quantity == 1:
       tense = ["drinks", "eats", "grows", "laughs", "thinks", "runs", "sleeps", "talks", "walks", "writes"]
    if tense and quantity == 1:
       verbs = ["drink", "eat", "grow", "laugh", "think", "run", "sleep", "talk", "walk", "write"]
    if tense == 1:
       verbs = ["will drink", "will eat", "will grow", "will laugh", "will think", "will run", "will sleep", "will talk", "will walk", "will write"]
       random.choice()
       return verbs
    
def make_sentence(quantity, tense):
   
   return
    

 
word= WORD.capitalize()
print(f"{get_determiner} {get_noun} {get_verb}")  


main()
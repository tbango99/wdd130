import math
import tkinter as tk
from tkinter import messagebox

def calculate():
    try:
        length = float(length_entry.get())
        width = float(width_entry.get())
        area = length * width
        diagonal = math.sqrt(length**2 + width**2)
        messagebox.showinfo("Results", f"The area of the rectangle is {area} square units.\nThe length of the diagonal of the rectangle is {diagonal} units.")
    except ValueError:
        messagebox.showerror("Error", "Please enter valid numbers for length and width.")

root = tk.Tk()
root.title("Carpentry Calculator")

length_label = tk.Label(root, text="Length:")
length_label.pack()

length_entry = tk.Entry(root)
length_entry.pack()

width_label = tk.Label(root, text="Width:")
width_label.pack()

width_entry = tk.Entry(root)
width_entry.pack()

calculate_button = tk.Button(root, text="Calculate", command=calculate)
calculate_button.pack()

root.mainloop()
#it is important to import function and below that is math function 
import math
# am going to add function that wii bring date and time on the program for week 2 assignment
from datetime import datetime
current_date = datetime.now()

width= int(input('enter the width of tire in mm: '));
aspect= int(input('enter the aspect ratio: '));
diameter= int(input('enter diameter: '));
tire_volume= math.pi *width**2*aspect*(width*aspect+2540*diameter)/10000000000;
#volume=round(volume, 2)

print('The approximate volume is {:.2f} liters'.format(tire_volume))
# function below will bring current date and time nd it is a float function
print(f'Date and Time\n {current_date}')
# opening a file inside called .txt and below that the code 
with open("volumes.txt", 'a') as f:
 #print (f"{current_date}, {width}, {aspect}, {diameter}, {round(volume, 2)}"'\n' )
  f.write('{}, {}, {}, {}, {}\n'.format(
  current_date,
  width,
  aspect,
  diameter,
  round(tire_volume, 2)
 ))
 
import math
def main():
    volume = float(input('What is the volume of the can: '))
    radius = float(input('What is the radius of the can: '))
    height = float(input('What is the height of the can: '))
    volume = (math.pi* radius^2)* height 
    surface_area = 2*math.pi*radius*(radius + height)
    